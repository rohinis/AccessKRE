#
# (c) Copyright 2017 Altair Engineering, Inc.  All rights reserved.
#
# This code is provided as is without any warranty, express or implied,
# or indemnification of any kind.
# All other terms and conditions are as specified in the Altair PBS EULA.
#

import sys
import os
import base64
import masterFileAnalyzer

if(refreshSourceName == "PRIMARY_FILE"):
	# Clear all the arguments.
	includeVal = []
	deleteArg("INCLUDE_FILES")
	deleteArg("INCLUDE_FILE_MAPPING")
	# Get the chosen master file value
	inputVal = getValue(refreshSourceName)
	if inputVal:
		# Identify the include file arguments from the chosen master file
		(includeVal, includeFileMap) = masterFileAnalyzer.parseMasterFileForIncludePaths(inputVal, "INCLUDE ", False)
		if includeVal:
			# If not empty insert into the application
			newIncludeArg={"name":"INCLUDE_FILES","type":"FILE_MULTI", "displayName":"Include Files","options":includeVal,"description":"Create arg FILE_MULTI.", "inputRequired":True,"refreshOnUpdate":False}
			insertArg(newIncludeArg)
			if includeFileMap:
				includeFileMap=base64.b64encode(includeFileMap.encode()).decode()
				newIncFlMapArg={"name":"INCLUDE_FILE_MAPPING","type":"STRING", "value":includeFileMap,"defaultValue":"","description":"Delimeter strin which will be used internally.","displayName":"INCLUDE FILE MAPPING","inputRequired":False,"refreshOnUpdate":False}
				insertArg(newIncFlMapArg)