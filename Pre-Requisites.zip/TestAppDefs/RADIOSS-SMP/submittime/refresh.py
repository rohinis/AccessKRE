#
# (c) Copyright 2017 Altair Engineering, Inc.  All rights reserved.
#
# This code is provided as is without any warranty, express or implied,
# or indemnification of any kind.
# All other terms and conditions are as specified in the Altair PBS EULA.
#

import sys
import re
import os
import base64
import masterFileAnalyzer

################################################################################
#'''
# Parses for the engine files. Engine file name will end with 0001-0009
#'''
def parseMasterFileForEnginePath( masterFilePath ):
	masterFilePath = masterFilePath.replace("\\", "/")
	if masterFilePath.startswith("pbscp"):
		masterFilePath = masterFilePath.replace("pbscp://","")
		masterFilePath = masterFilePath[masterFilePath.index('/') + 1:]
		import re
		if not re.match(r'^[a-zA-Z]:', masterFilePath):
			masterFilePath = "/" + masterFilePath
	masterFileDirPath = masterFilePath[:masterFilePath.rindex('/')]
	masterFileName = masterFilePath[len(masterFileDirPath)+1:].replace("0000.rad", "")
	engineFilePaths = []
	if masterFilePath:
		# Read engine files from the current location as master file
		engine_files = [x for x in os.listdir(masterFileDirPath) if x.endswith(".rad")]
		import re
		for engine_file in engine_files:
			fileFound=re.findall('\w*000[1-9]\.rad$', engine_file)
			if fileFound:
				if masterFileName in engine_file:
					engineFilePath = masterFileDirPath + "/" + engine_file
					engineFilePaths.append(engineFilePath)
	return engineFilePaths;

################################################################################

if(refreshSourceName == "PRIMARY_FILE"):
	# Clear all the arguments.
	includeVal = []
	deleteArg("INCLUDEFILES")
	deleteArg("INCLUDE_FILE_MAPPING")
	deleteArg("ENGINEFILES")
	# Get the chosen master file value
	inputVal = getValue(refreshSourceName)
	if inputVal:
		# Identify engine file paths
		engineFPs = parseMasterFileForEnginePath(inputVal)
		if not engineFPs:
			engineFPs = []
		newEngineArg={"name":"ENGINEFILES","type":"FILE_MULTI", "displayName":"Engine Files","options":engineFPs,"description":"Create arg FILE_MULTI_Engine.", "inputRequired":True,"refreshOnUpdate":False}
		insertArg(newEngineArg)
		# Identify the include file arguments from the chosen master file
		(includeVal, includeFileMap) = masterFileAnalyzer.parseMasterFileForIncludePaths(inputVal, "#include ", False)
		if includeVal:
			# If not empty insert into the application
			newIncludeArg={"name":"INCLUDEFILES","type":"FILE_MULTI", "displayName":"Include Files","options":includeVal,"description":"Create arg FILE_MULTI_Includes.", "inputRequired":True,"refreshOnUpdate":False}
			insertArg(newIncludeArg)
			if includeFileMap:
				includeFileMap=base64.b64encode(includeFileMap.encode()).decode()
				newIncFlMapArg={"name":"INCLUDE_FILE_MAPPING","type":"STRING", "value":includeFileMap,"defaultValue":"","description":"Delimeter strin which will be used internally.","displayName":"INCLUDE FILE MAPPING","inputRequired":False,"refreshOnUpdate":False}
				insertArg(newIncFlMapArg)