import subprocess, sys, os

def execcmd(cmd):
            try:
                        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,
stderr=subprocess.STDOUT)
                        data = ""
                        for line in p.stdout.readlines():
                                    data = data + line.decode('utf-8')
            except:
                        errTtype = sys.exc_type
                        try:
                                    errName = errTtype.__name__
                        except AttributeError:
                                    errName = errType
                        data = "Error: " + str(errName) + " --- " + str(sys.exc_value)
            return data
cmd = "CURRENT_PATH/TestData/testGenericActions.sh " + sys.argv[2]
print(sys.argv[1])
print (cmd)
print (execcmd(cmd))
sys.stdout.flush()