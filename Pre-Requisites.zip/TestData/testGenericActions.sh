#!/bin/sh

echo "Bash version ${BASH_VERSION}..."
cd /stage/$1/
mkdir testGenericActions
cd testGenericActions
for ((n=1;n<=10;n++))
do
  touch $n.txt
  echo "File number $n" >> $n.txt
done
cd ..
chmod 777 -R testGenericActions/*
chmod 777 *

ls -l /stage/$1/testGenericActions/ 

