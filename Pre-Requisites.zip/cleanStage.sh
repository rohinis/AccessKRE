#!/bin/sh
if [ -e userlist.txt ]
	then
	echo "###########################################"

for i in `more userlist.txt `
do
isDirPresent=/stage/$i
 if [ -d "$isDirPresent" ]
 then
   echo "Cleaning - /stage/""$i "
   cd /stage/
    rm -rf $i
else
   echo " stage root folder not present for user - " $i
fi

echo "###########################################"
done
echo "Deletig all jobs from pbs - including job history"
echo "###########################################"

qstat
qdel -x `qselect -x`
qdel -W force  `qselect`
qstat
else
    echo "userlist.txt not found "
    exit 1
fi
