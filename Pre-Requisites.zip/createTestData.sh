echo "begin" >> /tmp/out.txt
for i in `more userlist.txt `
do
echo
isDirPresent="/stage/"$i
echo "###########################################"  >> /tmp/out.txt

echo "stage root folder path - "$isDirPresent >> /tmp/out.txt


if [ -d "$isDirPresent" ]
then
 cd /stage
 chmod 777 $i
else
  echo "/stage/"$i" not present - creating it" >> /tmp/out.txt
  cd /stage
  mkdir $i
  chmod 777 $i
fi

cd /stage/$i

echo "Creating test data for user - "$i >> /tmp/out.txt
###################################################################
# Copying test data from prereq folder to stage root area of user #
###################################################################

cp /tmp/pre/TestData/*.zip .
find . -name "*.zip" -exec unzip -q {} \;
cd /stage/$i
rm -rf *.zip 

###################################################################
# Creating folders for upload scenarios                           #
###################################################################


mkdir JSUploads
mkdir ProfileFiles
mkdir UnZipOps
mkdir LotOfFiles
cd /stage/$i/LotOfFiles
for ((n=1;n<=225;n++))
do
  touch $n.txt
  echo "File number $n" >> $n.txt >> /tmp/out.txt
done
cd ..
chmod 777 *

###################################################################
# Creating Shortcut files for job submissions                     #
###################################################################


cd /stage/$i/
mkdir ShortCutFiles
cd  /stage/$i/ShortCutFiles/
cp  /stage/$i/JobsModule/InputDeck/*  /stage/$i/ShortCutFiles
ln -s /stage/$i/ShortCutFiles/Lag6elem_0000.rad /stage/$i/ShortCutFiles/SCLag6elem_0000.rad
ln -s /stage/$i/ShortCutFiles/Lag6elem_0001.rad /stage/$i/ShortCutFiles/SCLag6elem_0001.rad
ln -s /stage/$i/ShortCutFiles/bar.fem /stage/$i/ShortCutFiles/SCbar.fem
ln -s /stage/$i/ShortCutFiles/RunJob.sh /stage/$i/ShortCutFiles/SCRunJob.sh
chmod 777 -R /stage/$i/ShortCutFiles/

chmod 777 -R /stage/$i
chown $i:$i -R /stage/$i

echo "Finished creating test data for user - "$i >> /tmp/out.txt
echo "###########################################">> /tmp/out.txt
echo
done


echo "last line " >> /tmp/out.txt