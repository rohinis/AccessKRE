preReqFolder=$(pwd)
if [ -e /etc/pbsworks-pa.conf ]
	then
	echo "###########################################"

source /etc/pbsworks-pa.conf
cd $PA_EXEC
cd ../
uninstallerLoc=$(pwd)
cd $preReqFolder

echo "**********************************************"
echo " Uninstallaer location - "$uninstallerLoc
echo " PA_EXEC to be deleted - "$PA_EXEC
echo " PA_HOME to be deleted - "$PA_HOME
echo "**********************************************"
echo " Invoking Uninstaller in silent mode "
$uninstallerLoc/Change_Altair_Access_Installation -i silent
echo " Uninstalled Access in silent mode "
echo "**********************************************"
rm -rf $PA_EXEC
rm -rf $PA_HOME

if [ -z "$(ls -A $uninstallerLoc)" ]; then
   exit 1
else
   echo "Cleaning up residual files from - "$uninstallerLoc
   rm -rf $uninstallerLoc/*
fi

else
    echo "/etc/pbsworks-pa.conf not found "
    exit 1
fi